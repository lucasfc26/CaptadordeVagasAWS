// ============================================
// JobWatch - TanStack Query Hooks
// ============================================

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import type { JobFilters, NotificationFilters } from '@/types';
import {
  mockJobs,
  mockSearches,
  mockNotifications,
  mockDashboardStats,
  mockExecutions,
  mockSettings,
  mockUser,
} from '@/mock/data';

// Simulate API delay
const delay = (ms = 600) => new Promise((r) => setTimeout(r, ms));

// --- Dashboard ---
export function useDashboard() {
  return useQuery({
    queryKey: ['dashboard'],
    queryFn: async () => {
      await delay(400);
      return mockDashboardStats;
    },
    refetchInterval: 30000,
  });
}

// --- Jobs ---
export function useJobs(filters?: JobFilters) {
  return useQuery({
    queryKey: ['jobs', filters],
    queryFn: async () => {
      await delay();
      let jobs = [...mockJobs];

      if (filters?.onlyNew) jobs = jobs.filter((j) => j.status === 'NEW');
      if (filters?.status) jobs = jobs.filter((j) => j.status === filters.status);
      if (filters?.jobType) jobs = jobs.filter((j) => j.jobType === filters.jobType);
      if (filters?.location) jobs = jobs.filter((j) => `${j.location.city}, ${j.location.state}`.toLowerCase().includes(filters.location!.toLowerCase()));
      if (filters?.title) jobs = jobs.filter((j) => j.title.toLowerCase().includes(filters.title!.toLowerCase()));
      if (filters?.searchId) jobs = jobs.filter((j) => j.searchId === filters.searchId);

      if (filters?.sortBy === 'oldest') jobs.sort((a, b) => new Date(a.foundAt).getTime() - new Date(b.foundAt).getTime());
      else if (filters?.sortBy === 'location') jobs.sort((a, b) => a.location.city.localeCompare(b.location.city));
      else if (filters?.sortBy === 'title') jobs.sort((a, b) => a.title.localeCompare(b.title));
      else jobs.sort((a, b) => new Date(b.foundAt).getTime() - new Date(a.foundAt).getTime());

      return { data: jobs, total: jobs.length, page: 1, limit: 20, totalPages: 1 };
    },
  });
}

export function useNewJobs() {
  return useQuery({
    queryKey: ['jobs', 'new'],
    queryFn: async () => {
      await delay(300);
      return mockJobs.filter((j) => j.status === 'NEW');
    },
    refetchInterval: 30000,
  });
}

export function useJob(id: string) {
  return useQuery({
    queryKey: ['jobs', id],
    queryFn: async () => {
      await delay(400);
      const job = mockJobs.find((j) => j.id === id);
      if (!job) throw new Error('Vaga não encontrada');
      return job;
    },
    enabled: !!id,
  });
}

export function useMarkJobViewed() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      await delay(300);
      const job = mockJobs.find((j) => j.id === id);
      if (job) job.status = 'VIEWED';
      return job;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['jobs'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

// --- Searches ---
export function useSearches() {
  return useQuery({
    queryKey: ['searches'],
    queryFn: async () => {
      await delay();
      return mockSearches;
    },
  });
}

export function useSearch(id: string) {
  return useQuery({
    queryKey: ['searches', id],
    queryFn: async () => {
      await delay(400);
      const search = mockSearches.find((s) => s.id === id);
      if (!search) throw new Error('Busca não encontrada');
      return search;
    },
    enabled: !!id,
  });
}

export function useSearchHistory(id: string) {
  return useQuery({
    queryKey: ['searches', id, 'history'],
    queryFn: async () => {
      await delay(500);
      return mockExecutions.filter((e) => e.searchId === id);
    },
    enabled: !!id,
  });
}

export function useCreateSearch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: unknown) => {
      await delay(800);
      console.log('Creating search:', data);
      return { ...mockSearches[0], id: 'search-new', name: 'New Search' };
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['searches'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

export function useUpdateSearch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: unknown }) => {
      await delay(600);
      console.log('Updating search:', id, data);
      return mockSearches[0];
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['searches'] });
    },
  });
}

export function useDeleteSearch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      await delay(500);
      console.log('Deleting search:', id);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['searches'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

export function useToggleSearch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, action }: { id: string; action: 'pause' | 'resume' }) => {
      await delay(500);
      console.log(`${action} search:`, id);
      const search = mockSearches.find((s) => s.id === id);
      if (search) search.status = action === 'pause' ? 'PAUSED' : 'ACTIVE';
      return search;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['searches'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

// --- Notifications ---
export function useNotifications(filters?: NotificationFilters) {
  return useQuery({
    queryKey: ['notifications', filters],
    queryFn: async () => {
      await delay();
      let notifs = [...mockNotifications];
      if (filters?.status) notifs = notifs.filter((n) => n.status === filters.status);
      if (filters?.type) notifs = notifs.filter((n) => n.type === filters.type);
      if (filters?.read === false) notifs = notifs.filter((n) => n.status !== 'READ');
      return { data: notifs, total: notifs.length, page: 1, limit: 20, totalPages: 1 };
    },
  });
}

export function useMarkNotificationRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      await delay(300);
      const notif = mockNotifications.find((n) => n.id === id);
      if (notif) notif.status = 'READ';
      return notif;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['notifications'] });
    },
  });
}

// --- Settings ---
export function useSettings() {
  return useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      await delay(400);
      return mockSettings;
    },
  });
}

export function useUpdateSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      await delay(500);
      console.log('Updating settings:', data);
      return { ...mockSettings, ...data };
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['settings'] });
    },
  });
}

// --- User Profile ---
export function useProfile() {
  return useQuery({
    queryKey: ['profile'],
    queryFn: async () => {
      await delay(300);
      return mockUser;
    },
  });
}
