// ============================================
// JobWatch - API Services
// ============================================

import { apiClient } from './api';
import type {
  User,
  LoginCredentials,
  RegisterData,
  Job,
  JobFilters,
  Search,
  SearchConfig,
  MonitoringExecution,
  Notification,
  NotificationFilters,
  DashboardStats,
  UserSettings,
  PaginatedResponse,
} from '@/types';

// --- Auth ---
export const authService = {
  login: async (data: LoginCredentials) => {
    const res = await apiClient.post<{ user: User; token: string }>('/auth/login', data);
    return res.data;
  },
  register: async (data: RegisterData) => {
    const res = await apiClient.post<{ user: User; token: string }>('/auth/register', data);
    return res.data;
  },
  me: async () => {
    const res = await apiClient.get<User>('/auth/me');
    return res.data;
  },
  forgotPassword: async (email: string) => {
    const res = await apiClient.post('/auth/forgot-password', { email });
    return res.data;
  },
};

// --- Jobs ---
export const jobsService = {
  list: async (filters?: JobFilters) => {
    const res = await apiClient.get<PaginatedResponse<Job>>('/jobs', { params: filters });
    return res.data;
  },
  get: async (id: string) => {
    const res = await apiClient.get<Job>(`/jobs/${id}`);
    return res.data;
  },
  getNew: async () => {
    const res = await apiClient.get<Job[]>('/jobs/new');
    return res.data;
  },
  markViewed: async (id: string) => {
    const res = await apiClient.patch<Job>(`/jobs/${id}/viewed`);
    return res.data;
  },
};

// --- Searches ---
export const searchesService = {
  list: async () => {
    const res = await apiClient.get<Search[]>('/searches');
    return res.data;
  },
  get: async (id: string) => {
    const res = await apiClient.get<Search>(`/searches/${id}`);
    return res.data;
  },
  create: async (data: SearchConfig) => {
    const res = await apiClient.post<Search>('/searches', data);
    return res.data;
  },
  update: async (id: string, data: Partial<SearchConfig>) => {
    const res = await apiClient.patch<Search>(`/searches/${id}`, data);
    return res.data;
  },
  delete: async (id: string) => {
    const res = await apiClient.delete(`/searches/${id}`);
    return res.data;
  },
  pause: async (id: string) => {
    const res = await apiClient.post<Search>(`/searches/${id}/pause`);
    return res.data;
  },
  resume: async (id: string) => {
    const res = await apiClient.post<Search>(`/searches/${id}/resume`);
    return res.data;
  },
  history: async (id: string) => {
    const res = await apiClient.get<MonitoringExecution[]>(`/searches/${id}/history`);
    return res.data;
  },
};

// --- Notifications ---
export const notificationsService = {
  list: async (filters?: NotificationFilters) => {
    const res = await apiClient.get<PaginatedResponse<Notification>>('/notifications', { params: filters });
    return res.data;
  },
  markRead: async (id: string) => {
    const res = await apiClient.patch<Notification>(`/notifications/${id}/read`);
    return res.data;
  },
  markAllRead: async () => {
    const res = await apiClient.post('/notifications/read-all');
    return res.data;
  },
};

// --- Dashboard ---
export const dashboardService = {
  getStats: async () => {
    const res = await apiClient.get<DashboardStats>('/dashboard');
    return res.data;
  },
};

// --- Users / Settings ---
export const usersService = {
  updateProfile: async (data: { name?: string; email?: string }) => {
    const res = await apiClient.patch<User>('/users/me', data);
    return res.data;
  },
  getSettings: async () => {
    const res = await apiClient.get<UserSettings>('/users/me/settings');
    return res.data;
  },
  updateSettings: async (data: Partial<UserSettings>) => {
    const res = await apiClient.patch<UserSettings>('/users/me/settings', data);
    return res.data;
  },
  changePassword: async (data: { currentPassword: string; newPassword: string }) => {
    const res = await apiClient.patch('/users/me/password', data);
    return res.data;
  },
  deleteAccount: async () => {
    const res = await apiClient.delete('/users/me');
    return res.data;
  },
};
